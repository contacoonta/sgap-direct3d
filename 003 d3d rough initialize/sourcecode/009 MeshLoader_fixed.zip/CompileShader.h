#pragma once

#include <xnamath.h>


typedef struct ConstantBuffer
{
	XMMATRIX world;
	XMMATRIX view;
	XMMATRIX projection;

	XMFLOAT4 litDir;		// ������ ����
	XMFLOAT4 litCol;		// ������ ��

}CONSTANTBUFFER;


class CompileShader
{

public:
	static HRESULT		Create(CompileShader** ppshader, WCHAR* wfilename);
	static void			Delete(CompileShader** ppshader);

	HRESULT				Initialize(WCHAR* wfilename);
	void				Release();

	void				RenderPrepare(const void* psrcData);

private:
	HRESULT				CompileShaderFromFile(WCHAR* wFilename, LPCSTR strEntry, LPCSTR strShaderMdl, ID3DBlob** ppblob);

private:
	ID3D11InputLayout*      m_vertexlayout = nullptr;

	ID3D11VertexShader*     m_vertexshader = nullptr;
	ID3D11PixelShader*      m_pixelshader = nullptr;

	ID3D11Buffer*           m_constantbuffer = nullptr;
};


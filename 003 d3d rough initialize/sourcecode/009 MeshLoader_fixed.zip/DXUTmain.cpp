/*
	1. DXUT �� GUI �� Ȱ���ϱ�.
*/

#include "DXUT.h"
#include "DXUTgui.h"
#include "SDKmisc.h"

#include "Mesh.h"
#include "ObjLoader.h"
#include "CompileShader.h"



CDXUTDialogResourceManager	g_ResourceManager;
CDXUTDialog					g_GUI;


CompileShader*				g_shader = nullptr;
Mesh						g_mesh;

//CAMERA
XMMATRIX					g_view;
XMMATRIX					g_projection;
//LIGHT
XMFLOAT4					g_LitDir = XMFLOAT4(-0.577f, 0.577f, -0.577f, 1.0f);
XMFLOAT4					g_LitCol = XMFLOAT4(0.6f, 0.55f, 0.6f, 1.0f);



#define GUI_STATIC1		100
#define GUI_BUTTON		101


/*
	GUI �����
*/
VOID CALLBACK OnGUIEvent(UINT nEvent, int nControlID, 
								CDXUTControl* pControl, void* pUserContext)
{
	UINT u = 0;

	switch (nControlID)
	{
	case GUI_BUTTON:		
		DXUTToggleFullScreen();
		break;

	default:
		break;
	}
}

void GUIInit()
{
	g_GUI.Init(&g_ResourceManager);
	g_GUI.SetCallback(OnGUIEvent);

	g_GUI.AddStatic(GUI_STATIC1, L"GUI HELLO~!", 10, 50, 100, 50);	
	g_GUI.AddButton(GUI_BUTTON, L"Full Screen", 10, 100, 100, 50);
}



void CALLBACK OnFrameMove(double fTime, float fElapsedTime, void* pUserContext)
{

	// GUI STATIC ���ٰ� FrameRate ������ ���.
	/*CDXUTStatic * pstatic = g_GUI.GetStatic(GUI_STATIC1);
	if (pstatic)
		pstatic->SetText(DXUTGetFrameStats(true));*/


	g_mesh.Update();

}

LRESULT CALLBACK MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext)
{
	*pbNoFurtherProcessing = g_ResourceManager.MsgProc(hWnd, uMsg, wParam, lParam);
	if (*pbNoFurtherProcessing)
		return 0;
	
	*pbNoFurtherProcessing = g_GUI.MsgProc(hWnd, uMsg, wParam, lParam);
	if (*pbNoFurtherProcessing)
		return 0;

	return 0;
}

void CALLBACK OnKeyboard(UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext)
{
	if (bAltDown)
	{
		if (bKeyDown && nChar == 0x46 )
		{
			DXUTToggleFullScreen();
		}
	}
}

void CALLBACK OnMouse(bool bLeftButtonDown, bool bRightButtonDown, 
					bool bMiddleButtonDown, bool bSideButton1Down,
					bool bSideButton2Down, int nMouseWheelDelta,
					int xPos, int yPos, void* pUserContext)
{

}

bool CALLBACK OnDeviceChanging(DXUTDeviceSettings* pDeviceSettings, void* pUserContext)
{
	return true;
}

bool CALLBACK OnDeviceRemoved(void* pUserContext)
{
	return true;
}


bool CALLBACK IsDeviceAcceptable(const CD3D11EnumAdapterInfo *AdapterInfo,
							UINT Output, const CD3D11EnumDeviceInfo *DeviceInfo,
				DXGI_FORMAT BackBufferFormat, bool bWindowed, void* pUserContext)
{
	return true;
}

HRESULT CALLBACK OnCreateDevice(ID3D11Device* pd3dDevice, 
							const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc,
							void* pUserContext)
{

	ID3D11DeviceContext* pdevcon = DXUTGetD3D11DeviceContext();
	g_ResourceManager.OnD3D11CreateDevice(pd3dDevice, pdevcon);
	
	CompileShader::Create(&g_shader, L"lightShader.fx");

	ObjLoader loader;
	loader.BuildCube(g_mesh);


	return S_OK;
}

HRESULT CALLBACK OnResizedSwapChain(ID3D11Device* pd3dDevice, 
							IDXGISwapChain* pSwapChain,
							const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc,
							void* pUserContext)
{
	g_ResourceManager.OnD3D11ResizedSwapChain(pd3dDevice, pBackBufferSurfaceDesc);

	//VIEW
	XMVECTOR Eye = XMVectorSet(3.0f, 5.0f, -10.0f, 0.0f);
	XMVECTOR LookAt = XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);
	XMVECTOR Up = XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);
	g_view = XMMatrixLookAtLH(Eye, LookAt, Up);

	//PROJECTION
	LONG width = DXUTGetWindowWidth();
	LONG height = DXUTGetWindowHeight();
	g_projection = XMMatrixPerspectiveFovLH(XM_PIDIV2, (FLOAT)width / (FLOAT)height, 0.01f, 100.0f);


	
	return S_OK;
}

void CALLBACK OnFrameRender(ID3D11Device* pd3dDevice, 
							ID3D11DeviceContext* pd3dImmediateContext,
							double fTime, float fElapsedTime, void* pUserContext)
{
	float ClearColor[4] = { 0.176f, 0.196f, 0.667f, 0.0f };

	ID3D11RenderTargetView* pRTV = DXUTGetD3D11RenderTargetView();
	ID3D11DepthStencilView* pDSV = DXUTGetD3D11DepthStencilView();
	pd3dImmediateContext->ClearRenderTargetView(pRTV, ClearColor);
	pd3dImmediateContext->ClearDepthStencilView(pDSV, D3D11_CLEAR_DEPTH, 1.0, 0);
	
	

	/*
		SHADER CONSTANT BUFFER
	*/

	CONSTANTBUFFER cb;
	cb.world = XMMatrixTranspose(g_mesh.World());
	cb.view = XMMatrixTranspose(g_view);
	cb.projection = XMMatrixTranspose(g_projection);
	cb.litDir = g_LitDir;
	cb.litCol = g_LitCol;

	g_shader->RenderPrepare(&cb);

	g_mesh.Render();	

	/*
		GUI render
	*/
	//g_GUI.OnRender(fElapsedTime);
}

void CALLBACK OnReleasingSwapChain(void* pUserContext)
{
	g_ResourceManager.OnD3D11ReleasingSwapChain();
}

void CALLBACK OnDestroyDevice(void* pUserContext)
{
	g_mesh.Release();
	if (g_shader) CompileShader::Delete(&g_shader);

	g_ResourceManager.OnD3D11DestroyDevice();
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
								LPWSTR lpCmdLine, int nCmdShow)
{
	/*
		�⺻���� DXUT Callback ����
	*/
	DXUTSetCallbackFrameMove(OnFrameMove);
	DXUTSetCallbackKeyboard(OnKeyboard);
	DXUTSetCallbackMouse(OnMouse);
	DXUTSetCallbackMsgProc(MsgProc);
	DXUTSetCallbackDeviceChanging(OnDeviceChanging);
	DXUTSetCallbackDeviceRemoved(OnDeviceRemoved);

	/*
		D3D ���� �������̽��� Callback ���� ����
	*/
	DXUTSetCallbackD3D11DeviceAcceptable(IsDeviceAcceptable);
	DXUTSetCallbackD3D11DeviceCreated(OnCreateDevice);
	DXUTSetCallbackD3D11SwapChainResized(OnResizedSwapChain);
	DXUTSetCallbackD3D11FrameRender(OnFrameRender);
	DXUTSetCallbackD3D11SwapChainReleasing(OnReleasingSwapChain);
	DXUTSetCallbackD3D11DeviceDestroyed(OnDestroyDevice);
	
	/*
		���� ���� �� ����̽� ����
	*/
	DXUTInit(true, true, NULL);
	DXUTSetCursorSettings(true, true);

	GUIInit();

	DXUTCreateWindow(L"009 Obj Loader");
	DXUTCreateDevice(D3D_FEATURE_LEVEL_10_0, true, 1024, 768);
	
	DXUTMainLoop(); 

	return DXUTGetExitCode();
}
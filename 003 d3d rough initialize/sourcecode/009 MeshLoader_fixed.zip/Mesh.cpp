#include "DXUT.h"
#include "Mesh.h"
#include "CompileShader.h"


Mesh::Mesh()
{
	
}

Mesh::~Mesh()
{
	
}

void Mesh::Release()
{
	if (m_vertexbuffer) m_vertexbuffer->Release();
	if (m_indexbuffer) m_indexbuffer->Release();
}

void Mesh::Update()
{
	//WORLD
	m_world = XMMatrixIdentity();
}

void Mesh::Render()
{
	DXUTGetD3D11DeviceContext()->DrawIndexed(m_indexCnt, 0, 0);
}

#pragma once

#include "Mesh.h"

class ObjLoader
{

public:
			ObjLoader();
	virtual ~ObjLoader();

public:
	HRESULT		BuildCube(Mesh& mesh);
};


#include "DXUT.h"
#include "CompileShader.h"



HRESULT CompileShader::Create(CompileShader** ppshader, WCHAR* wfilename)
{
	if (*ppshader)
		return S_FALSE;

	*ppshader = new CompileShader;

	return (*ppshader)->Initialize(wfilename);
}

void CompileShader::Delete(CompileShader** ppshader)
{
	if (*ppshader == nullptr)
		return;

	(*ppshader)->Release();

	delete *ppshader;
	*ppshader = nullptr;
}



HRESULT CompileShader::CompileShaderFromFile(WCHAR* wFilename,
	LPCSTR strEntry, LPCSTR strShaderMdl, ID3DBlob** ppblob)
{
	HRESULT hr = S_OK;

	DWORD dwShaderFlags = D3DCOMPILE_ENABLE_STRICTNESS;
#if defined(DEBUG) || defined(_DEBUG)
	dwShaderFlags |= D3DCOMPILE_DEBUG;
#endif

	ID3DBlob* pErrorBlob = nullptr;

	hr = D3DX11CompileFromFile(wFilename, NULL, NULL,
		strEntry, strShaderMdl, dwShaderFlags, 0,
		NULL, ppblob, &pErrorBlob, NULL);

	if (pErrorBlob)
		pErrorBlob->Release();

	return S_OK;
}


void CompileShader::RenderPrepare(const void* psrcData)
{
	DXUTGetD3D11DeviceContext()->UpdateSubresource(m_constantbuffer, 0, NULL, psrcData, 0, 0);

	DXUTGetD3D11DeviceContext()->VSSetShader(m_vertexshader, NULL, 0);
	DXUTGetD3D11DeviceContext()->VSSetConstantBuffers(0, 1, &m_constantbuffer);

	DXUTGetD3D11DeviceContext()->PSSetShader(m_pixelshader, NULL, 0);
	DXUTGetD3D11DeviceContext()->PSSetConstantBuffers(0, 1, &m_constantbuffer);
}


HRESULT CompileShader::Initialize(WCHAR* wfilename)
{

	D3D11_INPUT_ELEMENT_DESC layoutPN[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	};

	UINT numElements = ARRAYSIZE(layoutPN);

	/*
		Vertex shader �����
	*/
	ID3DBlob* pVSblob = nullptr;
	// FX ���� �� VertexShader �ε�
	CompileShaderFromFile(wfilename, "VS", "vs_4_0", &pVSblob);
	DXUTGetD3D11Device()->CreateVertexShader(pVSblob->GetBufferPointer(),
										pVSblob->GetBufferSize(), NULL, &m_vertexshader);
	/*
		Vertex Layout �����
	*/
	DXUTGetD3D11Device()->CreateInputLayout(layoutPN, numElements,
					pVSblob->GetBufferPointer(), pVSblob->GetBufferSize(), &m_vertexlayout);
	pVSblob->Release();

	// VertexLayout �� device Context �� ����.
	DXUTGetD3D11DeviceContext()->IASetInputLayout(m_vertexlayout);


	/*
		Pixel shader �����
	*/
	ID3DBlob* pPSblob = nullptr;
	// FX ���� �� PixelShader �ε�
	CompileShaderFromFile(wfilename, "PS", "ps_4_0", &pPSblob);
	// Pixel CompileShader ����
	DXUTGetD3D11Device()->CreatePixelShader(pPSblob->GetBufferPointer(), 
					pPSblob->GetBufferSize(), NULL, &m_pixelshader);
	pPSblob->Release();

	/*
		Constant buffer 
	*/
	D3D11_BUFFER_DESC buffdesc;
	ZeroMemory(&buffdesc, sizeof(buffdesc));
	buffdesc.Usage = D3D11_USAGE_DEFAULT;
	buffdesc.ByteWidth = sizeof(CONSTANTBUFFER);
	buffdesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
	buffdesc.CPUAccessFlags = 0;
	// ��� ���� ����
	DXUTGetD3D11Device()->CreateBuffer(&buffdesc, NULL, &m_constantbuffer);

	return S_OK;
}

void CompileShader::Release()
{
	if (m_vertexlayout	)m_vertexlayout->Release();
	if (m_vertexshader	)m_vertexshader->Release();
	if (m_pixelshader	)m_pixelshader->Release();
	if (m_constantbuffer)m_constantbuffer->Release();
}